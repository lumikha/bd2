---
Template: blog
Address1: Suite 22c, Level 22 Tower One, Philippine Stock Exchange Plaza
Address2: Ayala Triangle, Ayala Avenue, Makati City, Manila 1226 Philippines 
phone: '+63-2-368-5773 '
Email: info@premier-gc.com
Copyright: 2015 Brian Dudley



social:
    - title: View Brian Dudley's profile in Facebook
      url: https://www.facebook.com/profile.php?id=100000044611744
      icon: /bd2/assets/img/icons/facebook_32.png
    - title: Check us out on Twitter
      url: https://twitter.com/brianwdudley1
      icon: /bd2/assets/img/icons/twitter_32.png
    - title: View Brian Dudley's profile in GoodReads
      url: https://www.goodreads.com/user/show/52039089-brian-dudley
      icon: /bd2/assets/img/icons/goodreads_32.png
    - title: View Brian Dudley's profile in Viadeo
      url: http://ph.viadeo.com/en/profile/brian.dudley
      icon: /bd2/assets/img/icons/viadeo_32.png
    - title: View Brian Dudley's profile in Quora
      url: https://www.quora.com/profile/Brian-Dudley-4
      icon: /bd2/assets/img/icons/quora_32.png
    - title: View Brian Dudley's profile in ZoomInfo
      url: http://www.zoominfo.com/z/BrianDudley
      icon: /bd2/assets/img/icons/zoominfo_32.png
    - title: View Brian Dudley's profile in LinkedIn
      url: https://ph.linkedin.com/in/brian-dudley-6b317851
      icon: /bd2/assets/img/icons/linkedin_32.png



---


