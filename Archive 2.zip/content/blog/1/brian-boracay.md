---
Title: Brian Dudley And Family Enjoy Boracay, Philippines

Template: blog-post
Date: May 04, 2016
Description: Brian Dudley, Makati City, Manila, Philippines
Address1: Suite 22c, Level 22 Tower One, Philippine Stock Exchange Plaza
Address2: Ayala Triangle, Ayala Avenue, Makati City, Manila 1226 Philippines 
phone: '+63-2-368-5773 '
Email: info@premier-gc.com
Copyright: 2015 Brian Dudley
Excerpt: Sun-kissed by Boracay With over 7,000 islands comprising the Philippine archipelago, there’s plethora of beautiful beaches to bask in. The 2012 best island in the world according to the travel magazine, Travel + Leisure, is here in the Philippines. Located approximately 315 km (196 mi) south of Manila and 2 km off the northwest tip 

social:
    - title: View Brian Dudley's profile in Facebook
      url: https://www.facebook.com/profile.php?id=100000044611744
      icon: /bd2/assets/img/icons/facebook_32.png
    - title: Check us out on Twitter
      url: https://twitter.com/brianwdudley1
      icon: /bd2/assets/img/icons/twitter_32.png
    - title: View Brian Dudley's profile in GoodReads
      url: https://www.goodreads.com/user/show/52039089-brian-dudley
      icon: /bd2/assets/img/icons/goodreads_32.png
    - title: View Brian Dudley's profile in Viadeo
      url: http://ph.viadeo.com/en/profile/brian.dudley
      icon: /bd2/assets/img/icons/viadeo_32.png
    - title: View Brian Dudley's profile in Quora
      url: https://www.quora.com/profile/Brian-Dudley-4
      icon: /bd2/assets/img/icons/quora_32.png
    - title: View Brian Dudley's profile in ZoomInfo
      url: http://www.zoominfo.com/z/BrianDudley
      icon: /bd2/assets/img/icons/zoominfo_32.png
    - title: View Brian Dudley's profile in LinkedIn
      url: https://ph.linkedin.com/in/brian-dudley-6b317851
      icon: /bd2/assets/img/icons/linkedin_32.png

---

__Sun-kissed by Boracay__

With over 7,000 islands comprising the Philippine archipelago, there’s plethora of beautiful beaches to bask in. The 2012 best island in the world according to the travel magazine, Travel + Leisure, is here in the Philippines. Located approximately 315 km (196 mi) south of Manila and 2 km off the northwest tip of Panay Island in the Western Visayas region of the Philippines, Boracay Island and its beaches have received a bucket of awards from numerous travel publications and agencies.

The Dudley family got to this postcard-sized tropical paradise, with a beach that’s only seven kilometers long, flying from capital Manila to Caticlan Airport. We then boarded a ferry from the Caticlan Jettyport which led us straight to Boracay Island. Our arrival at the main Boracay coast was were greeted with a long stretch of white sand beach with manifold restaurants, pubs, souvenir shops, hotels and, of course, a crowd of hundreds enjoying the kiss of the Boracay sun.

__Breathtaking Scenery__
Speaking of its sun, there’s that breathtaking scenery that unfolds during sunsets at Boracay. At one sunset, we decide to go lazy and strolled along the coast while allowing our feet to caress the warmth of the white sand. It was surely a picturesque ambience, the ball of red fire meeting the blue horizon. Boracay certainly has it’s romantic and relaxing atmosphere.

__A Place For Everyone__
Known for its perfect mix of daytime tranquility and frenzied nightlife, Boracay has a place for everyone. If you’re up for some adventure, you can try one of many watersports that the island has to offer. On our second day there, we soared with a parasail while being towed by a motorboat. A couple of feet above the deep blue sea, we saw the island from a bird’s eyes perspective. It was one exhilarating moment up in the sky.

We then decided to join of diverse group of tourists for the island hopping activity the rest of that day. We boarded a 40-seater motorboat and went to around five different islets/spots around Boracay and the opposite part of its main coast. The highlight of that activity would be the more peaceful Puka Beach as compared to the overly crowded main coast and the buffet lunch of seafood, barbecue and fresh native fruits. Yum!

While the young people were eager to start the party in different pubs in the island, we enjoyed some drinks while watching a jaw-dropping performance of fire dancers in one of the restaurants there. Such a show of death-dying skills! Kudos to the very talented fire benders!

We tried more watersports the next day. The flyfish ride, a hybrid of the original banana boat ride. Then we proceeded with helmet diving where we submerged more than 20 feet underwater with a 40 kilogram pressurised helmet on our shoulders that allowed us to breathe underwater. There, we met some schools of diverse fish species and played with them. It was astonishing to actually ‘walk’ underwater. — Brian Dudley, Makati City, Manila, Philippines